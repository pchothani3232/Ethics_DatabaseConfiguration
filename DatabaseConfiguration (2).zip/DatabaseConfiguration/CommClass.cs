﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatabaseConfiguration
{
    //shared/global class used to pass data between forms.
    public class CommClass
    {
        public static string Connection;  
        public static string filePath;
      
        //public string Connection { get; set; }
    }
}
