﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace DatabaseConfiguration
{
    public partial class SalesInvoice : Form
    {
        SqlConnection con = new SqlConnection(CommClass.Connection);

        ////1
        //DataTable dtSalesInvoice = new DataTable();

        public SalesInvoice()
        {
            InitializeComponent();

            dataGridView3.Visible = false;
           
           

        }

        private void SalesInvoice_Load(object sender, EventArgs e)
        {
            fillCombobox();
            AutogenerateCode();
            dataGridView2.Visible = false;
            
        }


        void fillCombobox()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("StateMaster_Sp", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Status", "select");

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            cmbState.DataSource = dt;
            cmbState.DisplayMember = "StateName";  
            //cmbState.ValueMember = "Id";
            cmbState.SelectedIndex = -1; // optional, to clear selection
            con.Close();
        }

        void AutogenerateCode()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SalesInvoice_Sp", con);  //LoginCredential = stored procedure name
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Status", "SalesInvoiceNumber");
            SqlParameter p = new SqlParameter("@SalesInvoiceNumber", SqlDbType.Decimal);
            p.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(p);
            cmd.ExecuteNonQuery(); // Run the stored procedure

            // Show result in textbox
            txtSalesInvoiceNo.Text = p.Value.ToString();
        }


        //Search by CustomerName and MobileNumber
        private void txtCustomerName_TextChanged(object sender, EventArgs e)
        {
            string searchText = txtCustomerName.Text.Trim();

            // Clear old selected data
            ClearCustomerData();

            if (!string.IsNullOrEmpty(searchText))
            {
                SqlCommand cmd = new SqlCommand("SalesInvoice_Sp", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@Status", "SearchByNameAndMobileNo");
                cmd.Parameters.AddWithValue("@CustomerName", txtCustomerName.Text);
                cmd.Parameters.AddWithValue("@MobileNumber", txtCustomerName.Text);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                dataGridView1.Visible = true;
                con.Close();
            }
            else
            {              
                dataGridView1.Visible = false;               
            }
        }

        private void dataGridView1_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
          
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dataGridView1.Rows.Count)
            {
                txtCustomerName.TextChanged -= txtCustomerName_TextChanged;
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                txtCustomerName.Text = row.Cells["Customer_Name"].Value?.ToString() ?? string.Empty;
                txtCustomerMobileNo.Text = row.Cells["Customer_PhoneNumber"].Value?.ToString() ?? string.Empty;
                txtCustomerAddress.Text = row.Cells["Customer_Address"].Value?.ToString() ?? string.Empty;
                cmbState.Text = row.Cells["Customer_State"].Value?.ToString() ?? string.Empty;
                txtCustomerName.TextChanged += txtCustomerName_TextChanged;
                dataGridView1.Visible = false;
            }
        }


        void ClearCustomerData()
        {
            txtCustomerAddress.Clear();
            txtCustomerMobileNo.Clear();
            cmbState.SelectedIndex = -1;
        }

        void ClearProductData()
        {
            
            txtProductRate.Clear();
            txtProductQty.Clear();
            txtProductDiscount.Clear();
            txtProductFreeQty.Clear();
            
            
        }

        //RadioButton....ProductName
        private void txtProductName_TextChanged(object sender, EventArgs e)
        {
            txtProductCode.Clear();
            if (rbProductName.Checked)
            {
                string searchText = txtProductName.Text.Trim();

                // Clear old selected data
                ClearProductData();

                if (!string.IsNullOrEmpty(searchText))
                {
                    SqlCommand cmd = new SqlCommand("Product_Sp", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Status", "SearchByName");
                    cmd.Parameters.AddWithValue("@Product_Name", txtProductName.Text);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView2.DataSource = dt;

                    dataGridView2.Visible = true;
                    con.Close();
                }
                else
                {
                    dataGridView2.Visible = false;
                }
            }

        }

        //RadioButton...ProductCode
        private void txtProductCode_TextChanged(object sender, EventArgs e)
        {
            txtProductName.Clear();
            if (rbProductCode.Checked)
            {
                string searchText = txtProductCode.Text.Trim();

                // Clear old selected data
                ClearProductData();

                if (!string.IsNullOrEmpty(searchText))
                {
                    SqlCommand cmd = new SqlCommand("Product_Sp", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Status", "SearchByCode");
                    cmd.Parameters.AddWithValue("@Product_Code", txtProductCode.Text);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView2.DataSource = dt;

                    dataGridView2.Visible = true;
                    con.Close();
                }
                else
                {
                    dataGridView2.Visible = false;
                }
            }
        }

        private void rbProductCode_CheckedChanged(object sender, EventArgs e)
        {
            if (rbProductCode.Checked)
            {
                txtProductCode_TextChanged(null, null); // Re-run code search
            }
        }

        private void rbProductName_CheckedChanged(object sender, EventArgs e)
        {
            if (rbProductName.Checked)
            {
                txtProductName_TextChanged(null, null); // Re-run name search
            }
        }

     
        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dataGridView2.Rows.Count)
            {             
                DataGridViewRow row = dataGridView2.Rows[e.RowIndex];

                txtProductName.TextChanged -= txtProductName_TextChanged;
                txtProductCode.TextChanged -= txtProductCode_TextChanged;

                txtProductName.Text = row.Cells["Product_Name"].Value?.ToString() ?? string.Empty;
                txtProductCode.Text = row.Cells["Product_Code"].Value?.ToString() ?? string.Empty;
                txtProductRate.Text = row.Cells["Product_SalesRate"].Value?.ToString() ?? string.Empty;
                txtProductQty.Text = row.Cells["Product_Qty"].Value?.ToString() ?? string.Empty;
                txtProductFreeQty.Text = row.Cells["Product_FreeQty"].Value?.ToString() ?? string.Empty;
                txtProductDiscount.Text = row.Cells["Product_Discount"].Value?.ToString() ?? string.Empty;
                lblAvailableQty.Text = row.Cells["Product_AvailableQty"].Value?.ToString() ?? string.Empty;

                txtProductName.TextChanged += txtProductName_TextChanged;
                txtProductCode.TextChanged += txtProductCode_TextChanged;

                dataGridView1.Visible = false;
            }
        }

        //AddButton
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (dataGridView3.Columns.Count == 0)
            {         
                dataGridView3.AutoGenerateColumns = false;
                dataGridView3.Visible = true;

                dataGridView3.Columns.Add("Product Name", "Product Name");
                dataGridView3.Columns.Add("Product Code", "Product Code");
                dataGridView3.Columns.Add("Product SalesRate", "Sales Rate");
                dataGridView3.Columns.Add("Product Qty", "Quantity");
                dataGridView3.Columns.Add("Product FreeQty", "Free Qty");
                dataGridView3.Columns.Add("Product Discount", "Discount");
                dataGridView3.Columns.Add("Product AvailableQty", "Available Qty");


                DataGridViewRow row = new DataGridViewRow();
                row.CreateCells(dataGridView3); // Ensure columns already created

                txtProductName.TextChanged -= txtProductName_TextChanged;
                txtProductCode.TextChanged -= txtProductCode_TextChanged;

                row.Cells[dataGridView3.Columns["Product Name"].Index].Value = txtProductName.Text;
                row.Cells[dataGridView3.Columns["Product Code"].Index].Value = txtProductCode.Text;
                row.Cells[dataGridView3.Columns["Product SalesRate"].Index].Value = txtProductRate.Text;
                row.Cells[dataGridView3.Columns["Product Qty"].Index].Value = txtProductQty.Text;
                row.Cells[dataGridView3.Columns["Product FreeQty"].Index].Value = txtProductFreeQty.Text;
                row.Cells[dataGridView3.Columns["Product Discount"].Index].Value = txtProductDiscount.Text;
                row.Cells[dataGridView3.Columns["Product AvailableQty"].Index].Value = lblAvailableQty.Text;

                txtProductName.TextChanged += txtProductName_TextChanged;
                txtProductCode.TextChanged += txtProductCode_TextChanged;

                dataGridView3.Rows.Add(row);
            }
        }

        //Clear()
        
    }
}
